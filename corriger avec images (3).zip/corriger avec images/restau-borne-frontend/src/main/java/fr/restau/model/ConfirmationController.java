package fr.restau.model;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ConfirmationController {

    @FXML private Label lblNumeroCommande;
    @FXML private Label lblTotalFinal;

    // Affiche les infos reçues après la validation
    public void afficherDetails(Commande commande) {
        lblNumeroCommande.setText("COMMANDE N° " + commande.getId()); //
        lblTotalFinal.setText("TOTAL : " + String.format("%.2f", commande.getPrixTotal()) + " €");
    }

    @FXML
    private void handleRetourAccueil(ActionEvent event) {
        try {
            // Réinitialise le panier pour la prochaine commande (REQ-ORD-006)
            PanierManager.reinitialiser();

            Parent root = FXMLLoader.load(getClass().getResource("/fxml/accueil.fxml"));
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setFullScreen(true); // Garde le mode borne (REQ-ARC-CLI-001)
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}