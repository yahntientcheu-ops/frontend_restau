package fr.restau.model;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.IOException;

public class AccueilController {

    @FXML
    private Button btnCommencer;

    @FXML
    private void handleCommencer(ActionEvent event) {
        try {
            // Chargement de la page categories.fxml
            // Note : Vérifie bien le nom du fichier (categories.fxml ou categorie.fxml ?)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/categories.fxml"));
            Parent root = loader.load();

            // Récupération du Stage actuel
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // OPTION A : Créer une scène avec une taille fixe (ex: 1200x800)
            Scene scene = new Scene(root, 1200, 800);

            // OPTION B : Si vous voulez du plein écran (recommandé pour une borne)
            stage.setScene(scene);
            stage.setFullScreen(true);

            // Changement de scène
            stage.setScene(scene);
            stage.show();

            System.out.println("Navigation vers la page catégories réussie !");

        } catch (IOException e) {
            System.err.println("❌ Erreur : Impossible de charger categories.fxml. Vérifiez le nom du fichier.");
            e.printStackTrace();
        }
    }
}