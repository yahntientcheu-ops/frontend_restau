package fr.restau.model;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import network.ApiClient;
import java.util.List;

public class app extends Application {

    private ApiClient apiClient = new ApiClient();

    @Override
    public void start(Stage primaryStage) {
        try {
            System.out.println("=== Démarrage de la Borne Restaurant ===");

            // 1. Chargement de la page d'accueil (accueil.fxml)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/accueil.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            primaryStage.setTitle("Borne de Commande - Accueil");
            primaryStage.setScene(scene);
            primaryStage.show();

            // 2. Appel réseau en arrière-plan pour ne pas figer l'écran d'accueil
            new Thread(() -> {
                try {
                    System.out.println("Récupération des données depuis le serveur...");
                    List<Plat> menu = apiClient.getTousLesPlats();

                    // Mise à jour de la console (ou de l'interface via le Controller plus tard)
                    Platform.runLater(() -> {
                        System.out.println("✅ Données reçues du serveur (" + menu.size() + " plats).");
                    });

                } catch (Exception e) {
                    Platform.runLater(() -> {
                        System.err.println("❌ Erreur réseau : " + e.getMessage());
                    });
                }
            }).start();

        } catch (Exception e) {
            System.err.println("❌ Erreur critique au démarrage : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}