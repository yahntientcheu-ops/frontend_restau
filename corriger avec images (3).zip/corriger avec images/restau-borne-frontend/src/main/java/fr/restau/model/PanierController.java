package fr.restau.model;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import network.ApiClient;
import java.io.IOException;

public class PanierController {

    @FXML private VBox containerLignes; // Zone où on va afficher chaque plat du panier
    @FXML private Label lblTotal;
    private ApiClient apiClient = new ApiClient();

    @FXML
    public void initialize() {
        rafraichirPanier();
    }

    private void rafraichirPanier() {
        containerLignes.getChildren().clear();
        Commande commande = PanierManager.getCommande(); //

        for (LigneCommande ligne : commande.getLignes()) {
            // Création visuelle d'une ligne (Nom x Quantité ... Prix)
            Label labelLigne = new Label(ligne.getPlat().getNom() + " x" + ligne.getQuantite() +
                    " - " + String.format("%.2f", ligne.getSousTotal()) + " €");
            labelLigne.getStyleClass().add("subtitle-white");
            containerLignes.getChildren().add(labelLigne);
        }

        lblTotal.setText("TOTAL GÉNÉRAL : " + String.format("%.2f", commande.getPrixTotal()) + " €"); //
    }

    @FXML
    private void handleValider(ActionEvent event) {
        try {
            // 1. Envoi au serveur (Étape 5)
            apiClient.envoyerCommande(PanierManager.getCommande());

            // 2. Navigation vers l'écran de confirmation
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/confirmation.fxml"));
            Parent root = loader.load();

            ConfirmationController conf = loader.getController();
            conf.afficherDetails(PanierManager.getCommande()); //

            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setFullScreen(true); //
        } catch (Exception e) {
            System.err.println("Erreur de validation : " + e.getMessage());
        }
    }

    @FXML
    private void handleRetour(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/menu_plats.fxml"));
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setFullScreen(true);
    }
}
