package network;

import fr.restau.model.Categorie;
import fr.restau.model.Plat;
import java.util.ArrayList;
import java.util.List;
import fr.restau.model.Commande; //

public class ApiClient {

    public List<Plat> getTousLesPlats() {
        List<Plat> catalogue = new ArrayList<>();

        // 1. DÉFINITION DES CATÉGORIES (doivent correspondre aux noms de vos dossiers images)
        Categorie catEntree = new Categorie(1L, "entrees", "");
        Categorie catPlat = new Categorie(2L, "menu_resistant", "");
        Categorie catDessert = new Categorie(3L, "dessert", "");
        Categorie catBoisson = new Categorie(4L, "rafraichissement", "");

        // --- 2. ENTRÉES ---
        catalogue.add(new Plat(101L, "Salade de Choux", "Salade croquante assaisonnée", 4.50, catEntree, "Végétarien"));
        catalogue.add(new Plat(102L, "Soupe Miso", "Soupe traditionnelle tofu et algues", 4.00, catEntree, "Chaud"));
        catalogue.add(new Plat(103L, "Nems au Poulet", "4 nems croustillants avec salade", 6.00, catEntree, "Chaud"));
        catalogue.add(new Plat(104L, "Nems aux Crevettes", "4 nems crevettes et légumes", 6.50, catEntree, "Chaud"));
        catalogue.add(new Plat(105L, "Gyoza Poulet", "5 raviolis japonais grillés", 6.50, catEntree, "Chaud"));
        catalogue.add(new Plat(106L, "Gyoza Legumes", "5 raviolis japonais aux légumes", 6.00, catEntree, "Végétarien"));
        catalogue.add(new Plat(107L, "Tempura Crevettes", "Beignets de crevettes légers", 7.50, catEntree, "Chaud"));
        catalogue.add(new Plat(108L, "Yakitori Boeuf Fromage", "2 brochettes boeuf fromage", 5.50, catEntree, "Chaud"));

        // --- 3. MENU RÉSISTANT ---
        catalogue.add(new Plat(201L, "Porc braise taiwanais", "Riz, oeuf mariné et bok choy", 14.50, catPlat, "Chaud"));
        catalogue.add(new Plat(202L, "Poulet crousciant", "Poulet aigre-douce et riz", 13.00, catPlat, "Chaud"));
        catalogue.add(new Plat(203L, "Brochettes de poulet yakitori", "Brochettes et nouilles", 12.50, catPlat, "Chaud"));
        catalogue.add(new Plat(204L, "Brochette de gambasse", "Gambas grillées au citron", 15.00, catPlat, "Chaud"));
        catalogue.add(new Plat(205L, "Bibimbap Coreen", "Boeuf, riz, légumes et oeuf", 14.00, catPlat, "Normal"));
        catalogue.add(new Plat(206L, "Porc Rouge", "Porc laqué caramélisé", 13.50, catPlat, "Chaud"));
        catalogue.add(new Plat(207L, "Nigiri", "Assortiment sushis et sashimis", 18.00, catPlat, "Froid"));
        catalogue.add(new Plat(208L, "Sushi", "Plateau saumon et makis", 16.50, catPlat, "Froid"));
        catalogue.add(new Plat(209L, "Galettes de Thon", "Makis frits thon épicé", 12.00, catPlat, "Chaud"));
        catalogue.add(new Plat(210L, "Porc a la japonaise", "Nouilles et raviolis vapeur", 14.00, catPlat, "Chaud"));

        // --- 4. DESSERTS ---
        catalogue.add(new Plat(301L, "Banana Sushi", "Banane, riz et chocolat", 6.50, catDessert, "Sucré"));
        catalogue.add(new Plat(302L, "Pudding Coco", "Coco et grenade", 5.50, catDessert, "Végétarien"));
        catalogue.add(new Plat(303L, "Chinese Mango Pudding", "Flan à la mangue", 5.00, catDessert, "Froid"));
        catalogue.add(new Plat(304L, "Boule de glace", "Trilogie de mochis glacés", 6.00, catDessert, "Froid"));
        catalogue.add(new Plat(305L, "Japanese Cotton Cheesecake", "Gâteau soufflé léger", 7.50, catDessert, "Normal"));
        catalogue.add(new Plat(306L, "Riz gluant mangue coco", "Classique Thaï", 7.00, catDessert, "Végétarien"));
        catalogue.add(new Plat(307L, "Pancake", "Dorayaki haricots rouges", 4.50, catDessert, "Sucré"));
        catalogue.add(new Plat(308L, "Taiyaki", "Gaufre poisson fourrée", 4.50, catDessert, "Chaud"));

        // --- 5. RAFRAÎCHISSEMENT ---
        catalogue.add(new Plat(401L, "Jus de bissap", "Fleur d'hibiscus", 3.50, catBoisson, "Frais"));
        catalogue.add(new Plat(402L, "Mogu Mogu Lychee", "Litchi et nata de coco", 3.00, catBoisson, "Frais"));
        catalogue.add(new Plat(403L, "Mogu Mogu Mango", "Mangue et nata de coco", 3.00, catBoisson, "Frais"));
        catalogue.add(new Plat(404L, "Mogu Mogu Cassis", "Cassis et nata de coco", 3.00, catBoisson, "Frais"));
        catalogue.add(new Plat(405L, "Vinut Seed Peach", "Graines basilic pêche", 3.50, catBoisson, "Frais"));
        catalogue.add(new Plat(406L, "Vinut Seed Cocktail", "Mélange fruits et basilic", 3.50, catBoisson, "Frais"));
        catalogue.add(new Plat(407L, "Vinut Seed Strawberry", "Fraise et basilic", 3.50, catBoisson, "Frais"));
        catalogue.add(new Plat(408L, "Vinut Seed Kiwi", "Kiwi et basilic", 3.50, catBoisson, "Frais"));
        catalogue.add(new Plat(409L, "Bubble Tea Fruite", "Thé perles et tapioca", 5.50, catBoisson, "Froid"));
        catalogue.add(new Plat(410L, "Ramune Drink", "Limonade japonaise", 4.00, catBoisson, "Pétillant"));

        return catalogue;
    }

    public void envoyerCommande(Commande commande) {
        // Affiche la validation dans votre console IntelliJ pour tester sans serveur
        System.out.println("--- COMMANDE VALIDÉE ---");
        System.out.println("Client : " + commande.getIdentifiantClient());
        System.out.println("Total : " + commande.getPrixTotal() + " €");
    }
}