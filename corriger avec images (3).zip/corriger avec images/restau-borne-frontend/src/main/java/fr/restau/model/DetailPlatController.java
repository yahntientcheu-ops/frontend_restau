package fr.restau.model;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class DetailPlatController {

    @FXML private Label lblNomPlat, lblDescription, lblPrix, lblQuantite;
    @FXML private ComboBox<String> comboOptions;
    @FXML private ImageView imgPlat;

    private Plat platActuel;
    private int quantite = 1;

    public void initData(Plat plat) {
        this.platActuel = plat;
        lblNomPlat.setText(plat.getNom());
        lblDescription.setText(plat.getDescription());
        lblPrix.setText(plat.getPrix() + " €");

        // Exemple d'options (REQ-ORD-003)
        comboOptions.getItems().addAll("Normal", "Épicé", "Végétarien");
        comboOptions.setValue("Normal");

        // Désactiver si non disponible (REQ-MNU-004)
        if (!plat.isEstDisponible()) {
            lblNomPlat.setText(plat.getNom() + " (INDISPONIBLE)");
            // On peut désactiver le bouton ajouter ici
        }
    }

    @FXML
    private void incrementerQuantite() {
        if (quantite < 9) { // Limite REQ-ORD-002
            quantite++;
            lblQuantite.setText(String.valueOf(quantite));
        }
    }

    @FXML
    private void decrementerQuantite() {
        if (quantite > 1) {
            quantite--;
            lblQuantite.setText(String.valueOf(quantite));
        }
    }

    @FXML
    private void ajouterAuPanier(ActionEvent event) {
        // Création de la ligne et ajout au gestionnaire de panier persistant
        LigneCommande ligne = new LigneCommande(platActuel, quantite, comboOptions.getValue());
        PanierManager.getCommande().getLignes().add(ligne);
        PanierManager.getCommande().calculerTotal();

        System.out.println("Plat ajouté au panier !");
        handleRetour(event);
    }

    @FXML
    private void handleRetour(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/menu_plats.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setFullScreen(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}