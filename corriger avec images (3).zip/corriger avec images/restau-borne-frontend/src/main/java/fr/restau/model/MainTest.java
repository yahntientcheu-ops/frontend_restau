package fr.restau.model; // Doit correspondre au dossier fr/restau/model
import network.ApiClient; // Correction ici : il faut le chemin complet
import java.util.List;

public class MainTest {
    public static void main(String[] args) {
        ApiClient api = new ApiClient();

        try {
            System.out.println("Connexion au serveur de la Personne A...");
            List<Plat> plats = api.getTousLesPlats();

            if (plats != null && !plats.isEmpty()) {
                System.out.println("✅ SUCCÈS ! Reçu : " + plats.get(0).getNom());
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR : Vérifiez le serveur sur le port 7070");
            e.printStackTrace();
        }
    }
}