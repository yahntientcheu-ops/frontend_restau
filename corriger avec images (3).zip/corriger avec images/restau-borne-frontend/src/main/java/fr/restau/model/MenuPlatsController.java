package fr.restau.model;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import network.ApiClient;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.InputStream;
import java.io.IOException;
import java.util.List;

public class MenuPlatsController {

    @FXML private Label lblTitreCategorie;
    @FXML private FlowPane containerPlats;
    @FXML private VBox containerPanierLateral; // À lier dans votre FXML
    @FXML private Label lblTotalLateral;      // À lier dans votre FXML

    private void rafraichirAffichagePanierLateral() {
        containerPanierLateral.getChildren().clear();
        Commande commande = PanierManager.getCommande();

        for (LigneCommande ligne : commande.getLignes()) {
            Label lbl = new Label(ligne.getPlat().getNom() + " x" + ligne.getQuantite());
            lbl.getStyleClass().add("subtitle-white");
            containerPanierLateral.getChildren().add(lbl);
        }

        lblTotalLateral.setText(String.format("%.2f €", commande.getPrixTotal())); //
    }
    @FXML
    private void handleValiderCommande() {
        try {
            // Chargement de la page Panier (Étape 4 de votre projet)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/panier.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) containerPlats.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setFullScreen(true); // Conserve le mode borne
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private ApiClient apiClient = new ApiClient();

    public void setTitreEtFiltrer(String titreRecu) {
        lblTitreCategorie.setText(titreRecu.toUpperCase());
        chargerPlats(titreRecu);
    }

    private void chargerPlats(String filtre) {
        String filtreNettoye = filtre.toLowerCase().trim()
                .replace("é", "e")
                .replace("è", "e")
                .split(" ")[0];

        new Thread(() -> {
            try {
                List<Plat> tousLesPlats = apiClient.getTousLesPlats();

                Platform.runLater(() -> {
                    containerPlats.getChildren().clear();
                    for (Plat p : tousLesPlats) {
                        String nomCatPlat = p.getCategorie().getNom().toLowerCase();
                        if (nomCatPlat.contains(filtreNettoye)) {
                            containerPlats.getChildren().add(creerCartePlat(p));
                        }
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private VBox creerCartePlat(Plat p) {
        VBox carte = new VBox(15);
        carte.getStyleClass().add("carte-plat");
        carte.setAlignment(javafx.geometry.Pos.CENTER);
        carte.setPrefSize(350, 500);

        // Nettoyage pour les noms de dossiers et fichiers
        String dossier = p.getCategorie().getNom().toLowerCase().trim()
                .replace("é", "e")
                .replace("è", "e")
                .replace("ê", "e")
                .replace(" ", "_");

        String fichier = p.getNom().toLowerCase().trim()
                .replace("é", "e")
                .replace("è", "e")
                .replace(" ", "_") + ".jpg";

        String chemin = "/images/" + dossier + "/" + fichier;

        try {
            InputStream is = getClass().getResourceAsStream(chemin);
            if (is != null) {
                ImageView imgView = new ImageView(new Image(is));
                imgView.setFitWidth(280);
                imgView.setPreserveRatio(true);
                carte.getChildren().add(imgView);
            } else {
                System.err.println("Image introuvable : " + chemin);
                Label placeholder = new Label("[Image non disponible]");
                placeholder.setStyle("-fx-text-fill: gray;");
                carte.getChildren().add(placeholder);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Label nom = new Label(p.getNom());
        nom.setStyle("-fx-font-weight: bold; -fx-font-size: 20px; -fx-text-fill: white;");

        Label prix = new Label(String.format("%.2f €", p.getPrix()));
        prix.setStyle("-fx-text-fill: #f1c40f; -fx-font-size: 22px;");

        Button btnAction = new Button("SÉLECTIONNER");
        btnAction.getStyleClass().add("button-selected");

        // Nouvelle action : Ajouter au manager et rafraîchir la vue
        btnAction.setOnAction(e -> {
            // 1. Ajouter le plat à la commande en cours
            Commande commande = PanierManager.getCommande();

            // On vérifie si le plat existe déjà pour augmenter la quantité,
            // sinon on crée une nouvelle ligne
            boolean trouve = false;
            for (LigneCommande ligne : commande.getLignes()) {
                if (ligne.getPlat().getId() == p.getId()) {
                    ligne.setQuantite(ligne.getQuantite() + 1);
                    trouve = true;
                    break;
                }
            }
            if (!trouve) {
                commande.getLignes().add(new LigneCommande(p, 1));
            }

            // 2. Rafraîchir l'affichage latéral (Étape suivante)
            rafraichirAffichagePanierLateral();
        });

        carte.getChildren().addAll(nom, prix, btnAction);
        return carte;
    }

    private void ouvrirDetail(Plat p) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/detail_plat.fxml"));
            Parent root = loader.load();
            DetailPlatController controller = loader.getController();
            controller.initData(p);
            Stage stage = (Stage) containerPlats.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setFullScreen(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleRetour() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/categories.fxml"));
            Stage stage = (Stage) containerPlats.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setFullScreen(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}