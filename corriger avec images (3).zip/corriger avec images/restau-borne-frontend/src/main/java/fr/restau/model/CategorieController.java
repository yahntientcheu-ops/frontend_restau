package fr.restau.model;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class CategorieController {

    @FXML
    private void handleNavigation(ActionEvent event) {
        try {
            // 1. Récupérer le texte du bouton (ex: "Entrées Délicates")
            String categorieNom = ((Button) event.getSource()).getText();

            // 2. Charger le FXML du menu
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/menu_plats.fxml"));
            Parent root = loader.load();

            // 3. Passer l'information au MenuPlatsController
            MenuPlatsController controller = loader.getController();
            controller.setTitreEtFiltrer(categorieNom);

            // 4. Afficher la scène
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setFullScreen(true); // REQ-CON-003
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void handleRetourAccueil(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/accueil.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setFullScreen(true);
    }
}
