package fr.restau.model;

public class PanierManager {
    // Stocke la commande unique pour toute la session
    private static Commande commandeEnCours = new Commande(1, "Borne-01");

    public static Commande getCommande() { return commandeEnCours; }

    public static void reinitialiser() {
        commandeEnCours = new Commande(1, "Borne-01");
    }

}